#' Append current UBPR data to database csv files
#'
#' This function prompts the user to choose the input zipfile that will be appended
#' to existing csv files. It also makes sure that the zip file chosen has kept
#' the same naming convention as downloaded from www.ffiec.gov since the package
#' will extract the date embedded in the zip file name. The instructions will
#' indicate that the filename itself should not be renamed. If it is renamed,
#' or an incorrect zip file is chosen, the script will stop running and provide
#' an appropriate error message. The function will also verify that
#' the data in the current zip file has not been previously appended to the
#' existing data base files by comparing the last reported date in the zip file
#' with the last report date available in the database files. If the last date in
#' both files are equal, the script will stop running and provide an appropriate
#' error message.
#'
#' @param zipfile=choose.files() By default, the user will be prompted to choose a .zip file. The user can add the character string of the full path to the current UBPR zip file to override the default.
#' @return Updated csv files containing the most recent UBPR data from FFIEC zip file.
#' @return ... placeholder for other arguments that could be added
#' @export
ubpr_updater <- function(zipfile=choose.files(caption="Select Current UBPR zip file",
                                              filters=Filters[c(".zip")])) {

  # SCRIPT PARAMETER ASSIGNMENTS ####

  options(warn=-1) # Suppress warning output from console

  # This will have to be adjusted to access the user's storage solution
  # Create 2 strings of names from master UBPR csv files to be updated ####
  ubpr_store <- "C:\\temp\\ubpr\\"

  master_csv_files <- list.files(ubpr_store, full.names=TRUE, pattern=".csv")                  # csv filename locations
  schedule_names <- gsub(".csv", "", list.files(ubpr_store, full.names=FALSE, pattern=".csv")) # schedule names

  # CHECK: Stop script if zip file does not appear to be UBPR file ####
  if (grepl("FFIEC CDR Bulk All UBPR Ratios",zipfile)) {

    message("Message: UBPR zip file choosen. Proceeding with data update...")
    Sys.sleep(2)

  } else {
    stop("Confirm that zip file contains UBPR data and try script again.")
  }

  # Assign a temporary directory to hold txt files from current zip download ####
  datafiles <- tempdir()

  # Import csv files to be updated
  for (i in 1:length(schedule_names)) {

    # CHECK: Does the csv file already contain data from the current zip file? ####
    master_date <- max(dplyr::pull(data.table::fread(master_csv_files[i], sep=',', select="calldate"))) # Extract most recent call report date in csv file

    zip_date <- max(dplyr::pull(data.table::fread(unzip(zipfile, file=unzip(zipfile, list=TRUE)[1,1], exdir=datafiles), select="Reporting Period")))
    zip_date <- as.Date(zip_date, format="%m/%d/%Y %I:%M:%S %p")


    # CHECK: Stop script if UBPR data already appears in the database files based on date ####
    if (assertthat::are_equal(as.character(master_date),as.character(zip_date))) {

      message(paste0("Current UBPR data (", zip_date, ") already exists in database csv file. \n  Moving to the next txt file."))
      Sys.sleep(0.5)
      next

    } else {

      message(paste0("Message: Current UBPR data for zip file for ", zip_date, "is updating..."))

      # Import and read Csv master file
      df <- data.table::fread(master_csv_files[i], sep=',')
      df <- dplyr::select(df, calldate, idrssd, starts_with("ubpr"))
      df <- dplyr::mutate(df, across(c(idrssd, starts_with("ubpr")), as.numeric),
                          calldate = as.Date(calldate))

      # Import and read txt file schedule from zip
      filein <- unzip(zipfile, list=TRUE)[1,1]

      # Get column names from txt file
      x <- unzip(zipfile, file=filein, exdir=datafiles)
      col_names <- names(data.table::fread(x, nrows=1))

      data <- data.table::fread(x, skip=2, col.names=col_names)
      data <- janitor::clean_names(data)
      data$calldate <- as.Date(data$reporting_period, format="%m/%d/%Y %I:%M:%S %p")
      data <- filter(data, calldate==max(data$calldate))
      data$idrssd   <- as.numeric(data$id_rssd)
      data <- dplyr::mutate(data, across(starts_with("ubpr"), as.numeric))
      data <- dplyr::select(data, calldate, idrssd, starts_with("ubpr"))

      write.csv(dplyr::bind_rows(df,data), file=master_csv_files[i], na="")

      }

    file.remove(list.files(path=datafiles, full.names=TRUE, pattern="UBPR"))

    message(paste0("Message: ", master_csv_files[i], " has been updated."))

  }

  message(paste0("The UBPR data for ",zip_date," has finished updating."))

  options(warn=0)

}
