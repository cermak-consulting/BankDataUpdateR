#' Append current Call Report data to data base files
#'
#' @description
#' This function prompts the user to choose the input zipfile that will be appended
#' to existing csv files. It also makes sure that the zip file chosen has kept
#' the same naming convention as downloaded from www.ffiec.gov since the package
#' will extract the date embedded in the zip file name. The instructions will
#' indicate that the filename itself should not be renamed. If it is renamed,
#' or an incorrect zip file is chosen, the script will stop running and provide
#' an appropriate error message. The function will also verify that
#' the data in the current zip file has not been previously appended to the
#' existing data base files by comparing the last reported date in the zip file
#' with the last report date available in the database files. If the last date in
#' both files are equal, the script will stop running and provide an appropriate
#' error message.
#'
#' @param zipfile=choose.files() By default, the user will be prompted to choose a .zip file. The user can add the character string of the full path to the current UBPR zip file to override the default.
#' @param ... placeholder for other arguments that could be added
#' @returns An updated database csv file.
#' @export
call_report_updater <- function(zipfile=choose.files(caption="Select current Call Report zip file",
                                                     filters=Filters[c(".zip")])) {

  # SCRIPT PARAMETER ASSIGNMENTS ####

  options(warn=-1) # Suppress warning output from console

  ## Where Call Report csv files for database which will be updated are located. ####
  call_data <- "c:\\temp\\call\\"

  ## Assign a temporary directory to hold txt files from current zip download ####
  datafiles <- tempdir()

  ## CHECK: Stop script if zip file does not appear to be Call Report file ####
  if (!grepl("FFIEC CDR Call Bulk All Schedules", zipfile)) {
    rm(list=ls())
    stop("Confirm that zip file contains Call Report data and try script again.")
  } else {
    message("Message: FFIEC Call Report zip file choosen. Proceeding with data update...")
    Sys.sleep(2)
  }

  ## Create vector of csv database files ####
  csv_files <- list.files(call_data)

  ## Create vector of txt file names from the zip file ####
  txt_files <- unzip(zipfile, list=TRUE)[,1]
  txt_files <- txt_files[grepl("Schedule", txt_files)]

  ## Extract calldate value from zipfile name ####
  zip_date <- as.Date(stringr::str_extract(zipfile, pattern="\\d{8}"),format="%m%d%Y")

  # START DATA UPDATES ####
  for (i in 1:length(txt_files)) {

    ## CHECK: Is the input file contain any data (some do not!) and if so, is it new? ####
    txtin <- unzip(zipfile, files=txt_files[i], exdir=datafiles)

    ### If txt file exists, does it have data? ####
    if (ncol(data.table::fread(txtin))<3) {
      message(paste0("Message: ", txt_files[i], " has no data. Moving on to next txt file."))
      Sys.sleep(1)
      next

    } else {

      ### If txt file has data, it is a new schedule or does it already exist? ####

      if (gsub(pattern="\\s\\d{8}","", gsub(pattern=".txt", " Data", txt_files[i])) %in% csv_files) {
        message(paste0("Message: ",txt_files[i], "is a new schedule this quarter. \n A new csv schedule file will be created"))

        x <- unzip(zipfile, file = txt_files[i], exdir=datafiles)
        col_names <- names(data.table::fread(x, nrows = 1))

        ### Read call report data from zip file and data cleanup ####
        data <- data.table::fread(x, skip = 2, col.names = col_names)
        data <- dplyr::select(data,-contains('v'))
        data <- dplyr::mutate(
          data,
          calldate = zip_date,
          IDRSSD = as.numeric(IDRSSD),
          across(starts_with("RCON"), as.numeric),
          across(starts_with("RCFD"), as.numeric),
          across(starts_with("RIAD"), as.numeric),
          across(starts_with("RSSD"), as.numeric),
          across(starts_with("TEXT"), as.character),
          across(where(is.character), ~ stringr::str_replace(.x, "CONF", "*")))
        data <- janitor::clean_names(data)
        data <- dplyr::relocate(data, calldate, idrssd)

        write.csv(data,
                  file = paste0(call_data,csv_files[i]),
                  na = "")

        ### R environment cleanup ####
        file.remove(list.files(
          path = datafiles,
          full.names = TRUE,
          pattern = "Call"
        ))
        rm(data)
        rm(df)

        message(paste0("Message: ", csv_files[i], " has been created."))

      } else {

        ## Extract name of txt file
        x <- unzip(zipfile, file = txt_files[i], exdir=datafiles)

        ## CHECK: does current UBPR already exist in database csv files? ####
        get_csv <- paste0(call_data, gsub("\\s\\d{8}.txt$", "", csv_files[i]))
        csv_date_max <- as.character(max(data.table::fread(get_csv)$calldate))

        if (csv_date_max == as.character(zip_date)) {
          message(paste0("Message: Data in ", txt_files[i], " already exists in database csv file. \n  Moving to the next txt file."))
          Sys.sleep(0.5)
          next

        } else {

        # Read call report data from zip file and data cleanup ####
        col_names <- names(data.table::fread(x, nrows = 1))

        data <- data.table::fread(x, skip = 2, col.names = col_names)
          data <- dplyr::select(data,-contains('v'))
          data <- dplyr::mutate(
            data,
            calldate = zip_date,
            IDRSSD = as.numeric(IDRSSD),
            across(starts_with("RCON"), as.numeric),
            across(starts_with("RCFD"), as.numeric),
            across(starts_with("RIAD"), as.numeric),
            across(starts_with("RSSD"), as.numeric),
            across(starts_with("TEXT"), as.character),
            across(where(is.character), ~ stringr::str_replace(.x, "CONF", "*")))
          data <- janitor::clean_names(data)
          data <- dplyr::relocate(data, calldate, idrssd)

          ### Import and read csv master file for zip file schedule ####
          get_csv <- paste0(call_data, gsub("\\s\\d{8}.txt$", "", csv_files[i]))

          df <- data.table::fread(get_csv)
          df <- dplyr::select(df,-starts_with("v"))
          df <- dplyr::mutate(
            df,
            calldate = as.Date(calldate),
            idrssd = as.numeric(idrssd),
            across(starts_with("rcon"), as.numeric),
            across(starts_with("rcfd"), as.numeric),
            across(starts_with("riad"), as.numeric),
            across(starts_with("rssd"), as.numeric),
            across(starts_with("text"), as.character),
            across(where(is.character), ~ stringr::str_replace(.x, "CONF", "*"))
          )

          ### Write updated Call Report data to csv database file ###
          write.csv(dplyr::bind_rows(df, data),
                    file = paste0(call_data,csv_files[i]),
                    na = "")

          ### R environment cleanup ####
          file.remove(list.files(
            path = datafiles,
            full.names = TRUE,
            pattern = "Call"
          ))

          message(paste0("Message: ", csv_files[i], " has been updated."))

        }
      }
    }

  }

  message(paste0("The Call Report data for ",
                 as.Date(stringr::str_extract(zipfile, pattern="\\d{8}"),format="%m%d%Y"),
                 " has finished updating."))

  options(warn=0)

}

